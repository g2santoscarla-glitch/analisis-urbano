# Documento editable para Canva

El documento completo contiene 126 diapositivas y conserva 28 figuras principales y el anexo de transporte, sus interpretaciones, conclusiones, notas, limitaciones, tablas y fuentes. La presentación original aportada no se ha modificado.

## Archivos

- Analisis_urbano_editable_Canva.pptx: documento maestro completo.
- 01_Analisis_y_resultados_Canva.pptx: páginas 1–76, resultados y método.
- 02_Tablas_fuentes_y_revision_Canva.pptx: páginas 77–126, tablas, revisión de la base y fuentes.
- Analisis_urbano_editable_Canva.pdf: solo vista previa de lectura; para editar o importar debe usarse el PPTX.
- Datos_y_trazabilidad.xlsx: libro de datos y procedencias del proyecto.

Los dos volúmenes son alternativas para trabajar por partes; el maestro ya incluye ambos.

## Importar y editar

En Canva, utiliza la opción de importar un archivo y selecciona el PPTX. Revisa una página de gráfico, otra de mapa y otra de tabla antes de continuar. Si aparecen objetos agrupados, comprueba las opciones de desagrupar disponibles. Conserva las fuentes y fechas al modificar contenido.

Los textos son cuadros de texto; las tablas son tablas nativas de PowerPoint. Los gráficos se construyen con barras, líneas, puntos y etiquetas independientes. Los mapas contienen polígonos, líneas y puntos vectoriales. No hay imágenes rasterizadas ni diapositivas aplanadas.

Los gráficos no tienen un vínculo automático con las tablas: si cambia una cifra, deben actualizarse también la etiqueta y la marca gráfica. Mover o redibujar polígonos no recalcula indicadores. El mapa de arbolado contiene miles de puntos para conservar los registros originales y puede requerir más tiempo de importación o edición.

## Qué se ha comprobado

El PPTX se abre con python-pptx y con LibreOffice. La revisión comprueba 29 figuras, todos sus textos, método/limitaciones, 57 URLs, las tablas y los 23 hallazgos de auditoría. No hay imágenes incrustadas, macros ni código Python en el documento. El PDF de lectura sirve para revisar visualmente la apertura.

No se ha importado el documento en Canva: no hay una integración disponible en esta sesión. Canva puede convertir objetos, reagruparlos o sustituir fuentes durante la importación; por ello no se certifica que todos sus controles sean idénticos a los de PowerPoint. Las tipografías solicitadas por el archivo son Georgia y Arial.

## Descarga y privacidad

Los archivos se conservan en el entorno. No se ha publicado el documento en Canva ni en GitHub. El repositorio analisis-urbano es público: cualquier subida allí requiere autorización explícita del usuario.
