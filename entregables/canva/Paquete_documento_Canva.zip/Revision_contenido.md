# Revisión independiente del contenido del PPTX

Archivo: `Analisis_urbano_editable_Canva.pptx`. SHA-256: `aab3a1234e4ece6c46385084b3db4c1fa8ee6c0c8c42f6ec405f0e342fe96ef4`.

- Apertura con python-pptx: correcta; 126 diapositivas.
- 12148 formas/objetos y 33 tablas nativas.
- Imágenes/Picture: 0; partes de imagen ppt/media: 0; nodos p:pic: 0.
- Integridad del ZIP: correcta.
- Cobertura: 29 figuras (28 principales y 1 anexo CRTM), con 0 campos textuales ausentes.
- Método/limitaciones: 15 párrafos comprobados; ausentes: [].
- Fuentes: 57 URLs únicas comprobadas; ausentes como texto visible: 0; enlaces clicables: 99.
- Auditoría del PDF original: 23 hallazgos comprobados; filas con valores ausentes: [].
- Código Python o macros embebidos: 0 partes; 0 coincidencias de patrones de código.
- Formas fuera del área de página (tolerancia de 1 pt): 0.

## Alcance de esta comprobación

Se normalizaron espacios y saltos de línea para verificar que los textos originales relevantes siguen en diapositivas visibles. No se utilizaron únicamente notas para acreditar cobertura. Las tablas se examinaron como tablas nativas. La revisión de renderizado en una aplicación de presentaciones se realiza por separado.

No se ha importado el archivo en Canva y esta prueba no garantiza que Canva mantenga todos los objetos o fuentes con idéntico comportamiento. Los gráficos están construidos con formas independientes, sin vínculo automático entre las tablas y sus marcas.
