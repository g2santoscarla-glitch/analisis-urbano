# Narrativa y síntesis para la presentación integral

De la posición territorial al funcionamiento cotidiano: delimitar el ámbito, reconocer su diversidad social y residencial, interpretar el soporte físico y contrastar accesibilidad, cuidados y paisaje. Cerrar con prioridades de comprobación apoyadas en los datos, sin convertir correlaciones en causas.

Presentación principal con selección razonada y síntesis de los ocho bloques; el atlas completo de 97 mapas y las tablas deben quedar ordenados como anexo de consulta. Evitar acumular mapas consecutivos sin explicar qué pregunta urbana resuelven.

## H01 · Tres secciones, más de un tercio de los residentes del barrio

El ámbito original concentra el 35,5 % de la población de San Juan Bautista en el 27,8 % de su superficie. La comparación con el barrio ofrece contexto, pero no sustituye el diagnóstico de las tres secciones.

**Conclusión.** Mantener juntas la lectura de barrio completo y la de detalle evita que un promedio oculte diferencias próximas.

**Fuente.** Padrón municipal 2026, Banco de Datos Madrid, series 0302010203242/0302010203232; límites SIGMA 24–25, EPSG:25830.

**Cautela.** Explotación municipal del Padrón; no equivale a cifras oficiales INE. Superficie total, no suelo residencial neto.

## H02 · La intensidad residencial cambia mucho entre secciones contiguas

15180 combina la mayor densidad de las tres secciones con menor proporción de mayores que 15148. Densidad y envejecimiento no describen el mismo patrón espacial.

**Conclusión.** Los servicios y el espacio libre deben valorarse con población, composición por edades y forma edificada, en lugar de asignar la misma demanda a todo el ámbito.

**Fuente.** Padrón municipal 2026, serie 0302010203242; áreas de límites oficiales SIGMA24, EPSG:25830.

**Cautela.** Densidad por superficie total. Edad no mide dependencia individual.

## H03 · El promedio favorable del barrio oculta una brecha interna

La renta neta por persona de 15148 es un 22,9 % inferior a la de 15178, aunque supera la referencia municipal. Ninguna de las tres alcanza el promedio de San Juan Bautista.

**Conclusión.** La comparación multiescalar muestra simultáneamente una posición relativamente favorable y diferencias dentro del ámbito.

**Fuente.** INE, Atlas de distribución de renta de los hogares, ingresos2023; Banco de Datos Madrid, series0403010000010/0403010000020.

**Cautela.** Medias, no medianas. No se calcula una renta media de la tríada sin ponderadores compatibles. No mide desigualdad individual ni hogares en pobreza.

## H04 · El alquiler presenta condiciones distintas a poca distancia

Las medianas por superficie de 15178 y 15180 superan la municipal; 15148 queda por debajo y presenta viviendas colectivas alquiladas de mayor superficie mediana.

**Conclusión.** Comparar solo el importe mensual oculta la composición del parque. Precio por superficie, tamaño e importe deben leerse juntos.

**Fuente.** Ministerio de Vivienda y Agenda Urbana, SEIR, fuentes tributarias2024; Banco de Datos Madrid0504040000020 y0504040000010.

**Cautela.** Medianas publicadas, no medias ni precios de anuncios. El intervalo P25–P75 mide dispersión. No calcular esfuerzo de alquiler con renta de2023 de distinto universo.

## H05 · Un parque colectivo y mayoritariamente propietario

La mayoría propietaria convive con una fracción arrendataria específica. El predominio de viviendas en edificios colectivos y el ciclo constructivo de1981–2000 diferencian la estructura del barrio de la de Ciudad Lineal.

**Conclusión.** La rehabilitación y el acceso a vivienda necesitan diagnósticos distintos; el parque mayoritariamente colectivo no determina por sí solo su tipología de implantación.

**Fuente.** INE, Censo de Población y Viviendas2021; Banco de Datos Madrid0303050200010/20/30/40.

**Cautela.** Datos del barrio, no extrapolables a las tres secciones. En tipo de edificio se cuentan viviendas, no edificios; antigüedad no certifica mal estado.

## H06 · 15148 concentra señales demográficas para revisar la proximidad de cuidados

15148 combina una proporción más alta de edades avanzadas con mayor peso de hogares formados por una persona de65 o más años. La coincidencia orienta una comprobación territorial de apoyos y recorridos.

**Conclusión.** Priorizar una auditoría de continuidad peatonal y acceso a cuidados en15148 es una hipótesis operativa que debe contrastarse con capacidad de servicios y trabajo de campo.

**Fuente.** Padrón2026, series0302010203242 y0302010600102; inventarios municipales de equipamientos.

**Cautela.** Denominador de hogares mayores solos: todos los hogares. Vivir solo no prueba soledad no deseada; edad no acredita dependencia.

## H07 · La referencia distrital de IGUALA aporta contexto, no un diagnóstico de sección

El IVTA de Ciudad Lineal queda por debajo de la referencia municipal publicada, mientras que la distancia en medio ambiente urbano y movilidad es reducida.

**Conclusión.** Una posición distrital relativamente favorable es compatible con necesidades concretas en una sección. El índice no debe sustituir los indicadores territoriales de detalle.

**Fuente.** Ayuntamiento de Madrid, IGUALA, conjunto datos.madrid.es300577-0, hoja Vul. esferas distritos, Fecha datos2024; metodología oficial IGUALA.

**Cautela.** Índice compuesto con normalización oficial; no escala0–10, porcentaje ni probabilidad individual. No mezclar normalizaciones de barrio y distrito.

## H08 · El paisaje verde inventariado no coincide con la densidad residencial

15178 concentra más árboles inventariados y una proporción mayor de superficies verdes que15148. La media del barrio no describe esta distribución interna.

**Conclusión.** La presencia espacial de recursos verdes debe cruzarse con recorridos, continuidad de sombra y accesibilidad, aspectos todavía no medidos por el inventario.

**Fuente.** Geoportal/SIGMA, ARBOLADO/11(ZV21) y CONSERVACION_ZZVV/4(ZV21)/5(PV24); consulta04/11/2026.

**Cautela.** Unión de superficies verdes sin doble recuento. Árboles de un inventario, no toda la vegetación. No acredita sombra, acceso ni titularidad pública/privada.

## H09 · Los cuatro barrios no son intercambiables por tamaño ni intensidad

San Pascual presenta la densidad más alta y menor proporción de verde inventariado; La Piovera tiene la menor densidad y El Salvador la mayor superficie verde relativa de los inventarios seleccionados.

**Conclusión.** La comparación debe usar tasas con denominadores equivalentes y conservar la escala de sección para no ocultar heterogeneidad interna.

**Fuente.** Padrón2026 y límites SIGMA; unión ZV21/PV24 consultada04/11/2026; indicadores_4_barrios.csv.

**Cautela.** Inventarios seleccionados, no toda la vegetación. Esta coincidencia entre indicadores no establece causalidad ni calidad del espacio verde.

## H10 · El funcionamiento cotidiano exige relacionar actividades, equipamientos y recorridos

El registro contabiliza370actividades en julio de2023, con presencia destacada de comercio/reparación y hostelería. La localización de servicios y transporte aporta un segundo plano espacial al perfil funcional.

**Conclusión.** La diversidad registrada debe contrastarse con capacidad de servicios y accesibilidad efectiva; el número de actividades no permite evaluar por sí solo la proximidad cotidiana.

**Fuente.** Ayuntamiento de Madrid, Censo de Locales y Actividades, Banco de Datos0402040000042; inventarios SIGMA y CRTM M6_Red/M4_Red.

**Cautela.** Actividades, no locales ni puestos de trabajo. No se calculan rutas ni tiempos a pie. CRTM referencia29/05/2026; no garantía de operación a fecha de consulta.

## Orden de los ocho bloques

### 1. Sociodemográfico

¿Quién vive aquí y cómo cambia su distribución?

Evolución2015–2026 → Pirámides y grandes grupos de edad → Densidad y nueve secciones de SJB → Comparación de cuatro barrios

La proximidad espacial convive con perfiles demográficos distintos.

### 2. Socioeconómico

¿Qué diferencias sociales y económicas oculta el promedio?

Renta de sección, barrio, distrito y ciudad → Mapa de renta en SJB → Cambio nominal2015–2023 → Educación25+

La posición económica relativa favorable no equivale a homogeneidad interna.

### 3. Residencial

¿Qué parque residencial sostiene la vida cotidiana?

Tenencia2021 → Tamaño y antigüedad2021 → Alquiler2024: mediana e intervaloP25–P75 → Mapas de precio, superficie e importe

Los niveles de alquiler deben interpretarse junto a la composición del parque.

### 4. Vulnerabilidad urbana

¿Dónde conviene comprobar necesidades de apoyo?

IGUALA2024 a escala distrital → Mapa80+ → Hogares65+solos → Cruce con equipamientos y viario

La vulnerabilidad no se asigna a personas por edad ni a secciones por el índice del distrito.

### 5. Morfológico

¿Cómo se ha formado y ocupado el soporte físico?

Ortofotos1957/1976/2023 → Huella y espacios no cubiertos → Alturas estimadas → Comparación de los cuatro barrios

Interpretar conjuntamente ocupación, verticalidad y población.

### 6. Tejido urbano

¿Qué grano y parcelación organizan la trama?

Manzanas frente a parcelas → Parcelación auténtica de Catastro → Ocupación geométrica de parcelas → Viviendas por tipo de edificio2021

La forma física no demuestra propiedad ni permite validar toda tipología manual.

### 7. Funcional y movilidad

¿Cómo se relacionan actividades, servicios y desplazamientos?

Perfil y evolución de actividades → Equipamientos sociosanitarios → Transporte público → Aceras y señalización peatonal

La presencia de una red o equipamiento requiere contrastarse con condiciones y capacidad de uso.

### 8. Paisaje público y privado

¿Cómo se distribuyen los recursos verdes y qué queda por comprobar?

Superficies verdesZV21+PV24 → Arbolado real y cuadrícula100m → Denominaciones botánicas → Comparación de los cuatro barrios

Inventario vegetal y espacio público no son equivalentes; acceso y titularidad requieren datos propios.

## Síntesis transversal

- **15148**: Más población80+ y mayor peso de hogares de mayores solos; renta inferior a las otras dos secciones. Comprobar: Continuidad peatonal y proximidad de cuidados y apoyos. No declarar dependencia, aislamiento o pobreza individual.
- **15180**: Mayor densidad de las tres secciones y menor peso de edades avanzadas. Comprobar: Capacidad y uso del espacio cotidiano, equipamientos y recorridos. No equiparar densidad alta a déficit de servicios o peor calidad de vida.
- **15178**: Mayor proporción de verde inventariado y más árboles del inventario que las otras dos secciones. Comprobar: Acceso, conectividad y calidad efectiva de los recursos verdes. No atribuir automáticamente carácter público, sombra o accesibilidad.

## Control editorial

No reutilizar la atribución errónea Ministerio de Hacienda/Atlas del alquiler en el atlas antiguo: organismo correcto MIVAU, SEIR; se ha corregido en los97mapas. El porcentaje verde actualizado uneZV21+PV24; no mezclar con comparativas antiguas que solo incluíanZV21. Conserva disponibles todos los mapas en el anexo aunque el cuerpo use una selección.