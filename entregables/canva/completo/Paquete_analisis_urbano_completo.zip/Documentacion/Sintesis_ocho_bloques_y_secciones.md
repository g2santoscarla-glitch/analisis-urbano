# Tablas de cierre del análisis urbano

## Síntesis por bloques

| Bloque | Hallazgo cuantitativo | Implicación urbana | Comprobación pendiente |
|---|---|---|---|
| 1 · Sociodemográfico | La tríada reúne 4.701 habitantes: el 35,5 % de San Juan Bautista en el 27,8 % de su superficie (2026). | La escala de sección permite distinguir intensidades y perfiles que el promedio del barrio suaviza. | Revisar capacidad y distribución de servicios con población por edad y recorridos cotidianos. |
| 2 · Socioeconómico | Renta neta por persona: 20.809 € en 15148 frente a 27.005 € en 15178; barrio, 28.260 € (2023). | La posición media favorable del barrio convive con diferencias internas de ingresos. | Contrastar composición de hogares y distribución de ingresos; no identificar pobreza individual mediante rentas medias. |
| 3 · Residencial | Alquiler colectivo mediano: 11,97 €/m²/mes en 15148; 15,75 en 15178 y 15,97 en 15180 (2024). | Los importes deben interpretarse junto con la superficie y composición del parque arrendado. | Examinar contratos, características y accesibilidad económica con universos y periodos compatibles; no calcular esfuerzo con estas medianas. |
| 4 · Vulnerabilidad urbana | En 15148, el 12,1 % de los habitantes tiene 80 o más años; el 21,6 % de los hogares corresponde a una persona de 65 o más años que vive sola (2026). | La coincidencia orienta una revisión territorial de cuidados y apoyos, sin atribuir dependencia ni aislamiento. | Comprobar capacidad de servicios, redes de apoyo y condiciones de los itinerarios. |
| 5 · Morfológico | La densidad varía de 9.228 habitantes/km² en 15148 a 32.902 en 15180 (2026). | La intensidad residencial exige leer conjuntamente población, huella edificada y verticalidad. | Contrastar las alturas estimadas y la ocupación con observación de edificios y usos de los espacios abiertos. |
| 6 · Tejido urbano | El 98,5 % de las viviendas del barrio se sitúa en edificios residenciales con tres o más viviendas (2021). | El soporte residencial es predominantemente colectivo; la estadística no distingue bloque abierto o manzana cerrada. | Validar tipologías con parcelas, huellas y trabajo de campo. Comprobar titularidad y acceso con fuentes específicas. |
| 7 · Funcional y movilidad | San Juan Bautista registra 370 actividades en julio de 2023: 110 de comercio/reparación y 71 de hostelería. | El perfil funcional se completa con la localización de equipamientos y transporte, sin equivaler a proximidad efectiva. | Actualizar actividades y comprobar capacidad, recorridos, frecuencias y condiciones peatonales. No inferir déficit por ausencia de puntos en una capa. |
| 8 · Paisaje público y privado | San Juan Bautista reúne 5.623 árboles ZV21; las superficies ZV21 y PV24 ocupan el 13,2 % del barrio (consulta2026). | El inventario revela distribución desigual de recursos verdes y permite comparar secciones. | Medir sombra y confort; verificar calidad, acceso y titularidad. Vegetación inventariada no equivale a espacio público. |

## Síntesis por secciones

| Sección | Hallazgo cuantitativo | Implicación urbana | Comprobación pendiente |
|---|---|---|---|
| 15148 | 1.038 habitantes; 12,1 % tiene 80 o más años. Los hogares de una persona de 65 o más años representan el 21,6 % (2026). | La estructura demográfica aconseja prestar atención específica a la vida cotidiana de las edades avanzadas. | Revisar apoyos y cuidados próximos, capacidad de servicios y continuidad de itinerarios; no dar por probada dependencia o soledad no deseada. |
| 15178 | 1.382 habitantes; 1.497 árboles ZV21 y un 39,6 % de superficie verde inventariada (Padrón2026; inventarios consultados2026). | La presencia verde es un rasgo territorial relevante, que no demuestra por sí solo calidad o acceso. | Verificar entradas, titularidad, conectividad peatonal, sombra efectiva y mantenimiento, distinguiendo inventario y uso público. |
| 15180 | 2.281 habitantes y 32.902 habitantes/km²; el 13,7 % tiene 65 o más años (2026). | La mayor intensidad residencial de las tres secciones debe leerse junto a su perfil de edad y soporte físico. | Contrastar usos, capacidad y condiciones del espacio cotidiano y de los equipamientos; la densidad no demuestra saturación ni peor calidad urbana. |

## Prioridades de análisis para2026

Prioridades de análisis para orientar comprobaciones posteriores. No son actuaciones aprobadas ni diagnósticos de déficits demostrados. Los años y universos de las fuentes se mantienen diferenciados.

- **1 · Cuidados y continuidad cotidiana**: Mayor proporción de población80+ y de hogares de mayores solos. Comprobar: Rutas, obstáculos, apoyo efectivo y capacidad de servicios.
- **2 · Intensidad residencial y espacio cotidiano**: Mayor densidad de las tres secciones. Comprobar: Uso observado de espacios y equipamientos; capacidad y confort.
- **3 · Acceso y continuidad de recursos verdes**: Concentración de superficies y árboles de los inventarios seleccionados. Comprobar: Acceso, titularidad, calidad, sombra y conectividad real.
- **4 · Condiciones residenciales y actualización funcional**: Diferencias de alquiler y antigüedad heterogénea de las fuentes. Comprobar: Vivienda y contratos comparables; actividades y transporte actualizados.

## Fuentes de cada fila

- **1 · Sociodemográfico**: Padrón municipal 2026 y límites SIGMA, EPSG:25830.
- **2 · Socioeconómico**: INE, ADRH; Banco de Datos Madrid, series0403010000010/20, ingresos2023.
- **3 · Residencial**: MIVAU, SEIR, fuentes tributarias2024; series0504040000010/20.
- **4 · Vulnerabilidad urbana**: Padrón2026, población y composición de hogares:0302010203242 y0302010600102.
- **5 · Morfológico**: Padrón2026, límites SIGMA y capa EDIFICIOS_ALTURAS.
- **6 · Tejido urbano**: INE, Censo2021; Banco de Datos Madrid0303050200020.
- **7 · Funcional y movilidad**: Censo municipal de Locales y Actividades,0402040000042; SIGMA y CRTM.
- **8 · Paisaje público y privado**: SIGMA ARBOLADO/11 y CONSERVACION_ZZVV/4–5; consulta04/11/2026.
- **15148**: Padrón municipal2026,0302010203242 y0302010600102.
- **15178**: Padrón2026; SIGMA ARBOLADO/11 y CONSERVACION_ZZVV/4–5, consulta04/11/2026.
- **15180**: Padrón2026 y límites SIGMA24, EPSG:25830.